const dogs = [
  {
    "name": "test",
    "age": 5,
    "src": "test",
    "facts": [
      "test loves eating popcorn.",
      "test is a terrible guard dog.",
      "test wants to cuddle with you!"
    ]
  },
  {
    "name": "mocked-dog",
    "age": 3,
    "src": "mocked-dog",
    "facts": [
      "mocked-dog believes that ball is life.",
      "mocked-dog likes snow.",
      "mocked-dog enjoys pawing other dogs."
    ]
  }
]

export default dogs